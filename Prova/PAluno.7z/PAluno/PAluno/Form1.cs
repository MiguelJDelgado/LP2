﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            string[,] NotasAlunos = new string[4, 3];
            double auxiliar, nota = 0, notafinal = 0;

            for (int i = 0; i < NotasAlunos.GetLength(0); i++)
            {
                for (int j = 0; j < NotasAlunos.GetLength(1); j++)
                {
                    NotasAlunos[i, j] = Interaction.InputBox($"Insira a nota do aluno {i + 1} do professor {j + 1}");
                    if (!double.TryParse(NotasAlunos[i, j], out auxiliar))
                    {
                        MessageBox.Show("Número inválido");
                        j--;
                    }
                    else
                    {
                        if (auxiliar < 0)
                        {
                            MessageBox.Show("Insira uma nota maior que 0");
                        }

                        else
                        {
                            ListaNotas.Items.Add($"Aluno  {i + 1} Nota Professor {j + 1}: {auxiliar.ToString("n2")}");
                            nota += auxiliar;
                            notafinal += auxiliar;
                        }
                    }
                }

                nota = nota / 3;
                ListaNotas.Items.Add($">> Média {nota.ToString("n2")}");
                ListaNotas.Items.Add("-------------------------------------");
                nota = 0;
            }
            
            notafinal = notafinal / 12;
            ListaNotas.Items.Add($">> Média Geral: {notafinal.ToString("n2")}");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ListaNotas.Items.Clear();   
        }
    }
}
