﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double Salario, SalFam, SalLiq, DesINSS, DesIRPF;
        int Filhos;
        string AliINSS, AliIRPF, Nome, Sal;
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            Nome = txtboxNome.Text;
            Sal = mskbxSalBruto.Text;

            if (string.IsNullOrEmpty(Nome))
            {
                MessageBox.Show("Preencha o seu nome");
            }

            else if (string.IsNullOrEmpty(Sal))
            {
                MessageBox.Show("Insira seu salário");
            }
            else
            {
                Salario = double.Parse(mskbxSalBruto.Text);
                Filhos = int.Parse(NumUPFilhos.Text);

                if (Salario <= 800.47)
                {
                    AliINSS = "7,65%";
                    DesINSS = (Salario * 0.0765);
                    txtboxINSS.Text = AliINSS;
                    txtboxDesINSS.Text = DesINSS.ToString("F2");
                }

                else if (Salario <= 1050)
                {
                    AliINSS = "8,65%";
                    DesINSS = (Salario * 0.0865);
                    txtboxINSS.Text = AliINSS;
                    txtboxDesINSS.Text = DesINSS.ToString("F2");
                }

                else if (Salario <= 1400.77)
                {
                    AliINSS = "9,00%";
                    DesINSS = (Salario * 0.09);
                    txtboxINSS.Text = AliINSS;
                    txtboxDesINSS.Text = DesINSS.ToString("F2");
                }

                else if (Salario <= 2801.56)
                {
                    AliINSS = "11,00%";
                    DesINSS = (Salario * 0.11);
                    txtboxINSS.Text = AliINSS;
                    txtboxDesINSS.Text = DesINSS.ToString("F2");
                }

                else
                {
                    AliINSS = "Teto";
                    DesINSS = 308.17;
                    txtboxINSS.Text = AliINSS;
                    txtboxDesINSS.Text = DesINSS.ToString("F2");
                }

                if (Salario <= 1257.12)
                {
                    AliIRPF = "0,00%";
                    txtboxDesIRPF.Text = "0,00";
                    txtboxIRPF.Text = AliIRPF;
                }

                else if (Salario <= 2512.08)
                {
                    AliIRPF = "15,00%";
                    DesIRPF = (Salario * 0.15);
                    txtboxDesIRPF.Text = DesIRPF.ToString("F2");
                    txtboxIRPF.Text = AliIRPF;
                }

                else
                {
                    AliIRPF = "27.5%";
                    DesIRPF = (Salario * 0.275);
                    txtboxDesIRPF.Text = DesIRPF.ToString("F2");
                    txtboxIRPF.Text = AliIRPF;
                }

                if (Salario <= 435.52)
                {
                    SalFam = (Filhos * 22.33);
                    txtboxFam.Text = SalFam.ToString("F2");
                }

                else if (Salario <= 654.61)
                {
                    SalFam = (Filhos * 15.74);
                    txtboxFam.Text = SalFam.ToString("F2");
                }

                else
                {
                    SalFam = 0;
                    txtboxFam.Text = SalFam.ToString("F2");
                }

                SalLiq = Salario + SalFam - DesINSS - DesIRPF;
                txtboxSalLiq.Text = SalLiq.ToString("F2");

            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxNome.Clear();
            mskbxSalBruto.Clear();
            NumUPFilhos.ResetText();
            txtboxINSS.Clear();
            txtboxIRPF.Clear();
            txtboxFam.Clear();
            txtboxDesINSS.Clear();
            txtboxDesIRPF.Clear();
            txtboxSalLiq.Clear();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
} 
