﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalB = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalF = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDesINSS = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.NumUPFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtboxNome = new System.Windows.Forms.TextBox();
            this.txtboxSalLiq = new System.Windows.Forms.TextBox();
            this.txtboxDesIRPF = new System.Windows.Forms.TextBox();
            this.txtboxDesINSS = new System.Windows.Forms.TextBox();
            this.txtboxINSS = new System.Windows.Forms.TextBox();
            this.txtboxIRPF = new System.Windows.Forms.TextBox();
            this.txtboxFam = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumUPFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(140, 43);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(93, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome Funcionário";
            // 
            // lblSalB
            // 
            this.lblSalB.AutoSize = true;
            this.lblSalB.Location = new System.Drawing.Point(140, 89);
            this.lblSalB.Name = "lblSalB";
            this.lblSalB.Size = new System.Drawing.Size(67, 13);
            this.lblSalB.TabIndex = 1;
            this.lblSalB.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(140, 137);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de Filhos";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(141, 289);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblIRPF.TabIndex = 3;
            this.lblIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalF
            // 
            this.lblSalF.AutoSize = true;
            this.lblSalF.Location = new System.Drawing.Point(141, 337);
            this.lblSalF.Name = "lblSalF";
            this.lblSalF.Size = new System.Drawing.Size(76, 13);
            this.lblSalF.TabIndex = 4;
            this.lblSalF.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(141, 382);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(76, 13);
            this.lblSalLiq.TabIndex = 5;
            this.lblSalLiq.Text = "Salário Liquido";
            // 
            // lblDesINSS
            // 
            this.lblDesINSS.AutoSize = true;
            this.lblDesINSS.Location = new System.Drawing.Point(462, 242);
            this.lblDesINSS.Name = "lblDesINSS";
            this.lblDesINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDesINSS.TabIndex = 6;
            this.lblDesINSS.Text = "Desconto INSS";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Location = new System.Drawing.Point(141, 242);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(73, 13);
            this.lblINSS.TabIndex = 7;
            this.lblINSS.Text = "Aliquota INSS";
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(462, 289);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDesIRPF.TabIndex = 9;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(443, 69);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(110, 37);
            this.btnVerificar.TabIndex = 10;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // NumUPFilhos
            // 
            this.NumUPFilhos.Location = new System.Drawing.Point(246, 130);
            this.NumUPFilhos.Name = "NumUPFilhos";
            this.NumUPFilhos.Size = new System.Drawing.Size(81, 20);
            this.NumUPFilhos.TabIndex = 11;
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(246, 86);
            this.mskbxSalBruto.Mask = "000000.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(133, 20);
            this.mskbxSalBruto.TabIndex = 12;
            // 
            // txtboxNome
            // 
            this.txtboxNome.Location = new System.Drawing.Point(246, 40);
            this.txtboxNome.Name = "txtboxNome";
            this.txtboxNome.Size = new System.Drawing.Size(307, 20);
            this.txtboxNome.TabIndex = 13;
            // 
            // txtboxSalLiq
            // 
            this.txtboxSalLiq.Enabled = false;
            this.txtboxSalLiq.Location = new System.Drawing.Point(246, 379);
            this.txtboxSalLiq.Name = "txtboxSalLiq";
            this.txtboxSalLiq.Size = new System.Drawing.Size(122, 20);
            this.txtboxSalLiq.TabIndex = 19;
            // 
            // txtboxDesIRPF
            // 
            this.txtboxDesIRPF.Enabled = false;
            this.txtboxDesIRPF.Location = new System.Drawing.Point(569, 286);
            this.txtboxDesIRPF.Name = "txtboxDesIRPF";
            this.txtboxDesIRPF.Size = new System.Drawing.Size(122, 20);
            this.txtboxDesIRPF.TabIndex = 20;
            // 
            // txtboxDesINSS
            // 
            this.txtboxDesINSS.Enabled = false;
            this.txtboxDesINSS.Location = new System.Drawing.Point(569, 239);
            this.txtboxDesINSS.Name = "txtboxDesINSS";
            this.txtboxDesINSS.Size = new System.Drawing.Size(122, 20);
            this.txtboxDesINSS.TabIndex = 21;
            // 
            // txtboxINSS
            // 
            this.txtboxINSS.Enabled = false;
            this.txtboxINSS.Location = new System.Drawing.Point(246, 241);
            this.txtboxINSS.Name = "txtboxINSS";
            this.txtboxINSS.Size = new System.Drawing.Size(122, 20);
            this.txtboxINSS.TabIndex = 22;
            // 
            // txtboxIRPF
            // 
            this.txtboxIRPF.Enabled = false;
            this.txtboxIRPF.Location = new System.Drawing.Point(246, 286);
            this.txtboxIRPF.Name = "txtboxIRPF";
            this.txtboxIRPF.Size = new System.Drawing.Size(122, 20);
            this.txtboxIRPF.TabIndex = 23;
            // 
            // txtboxFam
            // 
            this.txtboxFam.Enabled = false;
            this.txtboxFam.Location = new System.Drawing.Point(246, 330);
            this.txtboxFam.Name = "txtboxFam";
            this.txtboxFam.Size = new System.Drawing.Size(122, 20);
            this.txtboxFam.TabIndex = 24;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(443, 116);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(110, 34);
            this.btnLimpar.TabIndex = 25;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(443, 348);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(110, 35);
            this.btnSair.TabIndex = 26;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtboxFam);
            this.Controls.Add(this.txtboxIRPF);
            this.Controls.Add(this.txtboxINSS);
            this.Controls.Add(this.txtboxDesINSS);
            this.Controls.Add(this.txtboxDesIRPF);
            this.Controls.Add(this.txtboxSalLiq);
            this.Controls.Add(this.txtboxNome);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.NumUPFilhos);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblDesINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalF);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalB);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NumUPFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalB;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalF;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDesINSS;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.NumericUpDown NumUPFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.TextBox txtboxNome;
        private System.Windows.Forms.TextBox txtboxSalLiq;
        private System.Windows.Forms.TextBox txtboxDesIRPF;
        private System.Windows.Forms.TextBox txtboxDesINSS;
        private System.Windows.Forms.TextBox txtboxINSS;
        private System.Windows.Forms.TextBox txtboxIRPF;
        private System.Windows.Forms.TextBox txtboxFam;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

