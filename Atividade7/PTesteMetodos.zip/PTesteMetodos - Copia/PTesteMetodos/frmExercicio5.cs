﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }
        Random randNum = new Random();
        private void btnSorteio_Click_1(object sender, EventArgs e)
        {
            try
            {
                int Num1, Num2, NumSorteado;
                Num1 = int.Parse(txtNumero1.Text);
                Num2 = int.Parse(txtNumero2.Text);


                if (Num1 < Num2)
                {
                    NumSorteado = randNum.Next(Num1, Num2);
                    lblResultado.Text = NumSorteado.ToString();
                }

                else
                {
                    MessageBox.Show("O primeiro número deve ser menor que o segundo");
                    txtNumero1.Clear();
                    txtNumero2.Clear();
                    lblResultado.ResetText();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Insira apenas números");
            }
        }
    }
    
}
