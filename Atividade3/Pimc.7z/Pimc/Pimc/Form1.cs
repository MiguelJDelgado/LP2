﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string situacao;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                peso = double.Parse(mskbxPeso.Text);
                altura = double.Parse(mskbxAltura.Text);
            

                if (altura <= 0 || peso <= 0)
                {
                    MessageBox.Show("Altura e Peso devem ser maiores do que 0!");
                    mskbxIMC.Clear();
                    mskbxAltura.Focus();
                }
                else
                {
                    imc = peso / (altura * altura);
                    imc = Math.Round(imc, 1);

                    mskbxIMC.Text = Convert.ToString(imc);

                    if (imc <= 18.5) 
                    {
                        situacao = ("Abaixo do Normal");
                        lblSituacao.Text = situacao;
                    }

                    else if (imc <= 24.9)
                    {
                        situacao = ("Normal");
                        lblSituacao.Text = situacao;
                    }
                    else if (imc <= 29.9)
                    {
                        situacao = ("Sobrepeso");
                        lblSituacao.Text = situacao;
                    }
                    else if (imc <= 34.9)
                    {
                        situacao = ("Obesidade grau I");
                        lblSituacao.Text = situacao;
                    }
                    else if (imc <= 39.9)
                    {
                        situacao = ("Obesidade grau II");
                        lblSituacao.Text = situacao;
                    }
                    else if (imc > 40)
                    {
                        situacao = ("Obesidade grau III");
                        lblSituacao.Text = situacao;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Insira apenas números!:");
            }
            
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxIMC.Clear();
        }
    }
}
