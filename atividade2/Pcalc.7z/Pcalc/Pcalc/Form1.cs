﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1, num2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = double.Parse(txtboxNum.Text);
                num2 = double.Parse(txtboxNum2.Text);
                resultado = num1 * num2;
                txtboxResultado.Text = Convert.ToString(resultado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insira apenas números!:  " + ex.Message);
            }
            txtboxNum.Focus();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            try
            {

                num1 = double.Parse(txtboxNum.Text);
                num2 = double.Parse(txtboxNum2.Text);

                if (num2 == 0)
                {
                    MessageBox.Show("Não é possível realizar divisões por 0!");
                    txtboxResultado.Clear();
                }
                else
                {
                    resultado = num1 / num2;
                    txtboxResultado.Text = Convert.ToString(resultado);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Insira apenas números!:  " + ex.Message);
            }
        
            txtboxNum.Focus();
        
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = double.Parse(txtboxNum.Text);
                num2 = double.Parse(txtboxNum2.Text);
                resultado = num1 + num2;
                txtboxResultado.Text = Convert.ToString(resultado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insira apenas números!:  " + ex.Message);
            }
            txtboxNum.Focus();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = double.Parse(txtboxNum.Text);
                num2 = double.Parse(txtboxNum2.Text);
                resultado = num1 - num2;
                txtboxResultado.Text = Convert.ToString(resultado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insira apenas números!:  " + ex.Message);
            }
            txtboxNum.Focus();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxNum.Clear();
            txtboxNum2.Clear();
            txtboxResultado.Clear();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        
    }
   
}
