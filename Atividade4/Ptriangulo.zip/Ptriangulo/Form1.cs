﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        string resultado, valorA, valorB, valorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();                       //BOTÃO FECHAR APLICAÇÃO
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            try
            {
                valorA = txtA.Text;
                valorB = txtB.Text;        //VALIDAÇÃO DE ESPAÇO PREENCHIDO PELO USUÁRIO
                valorC = txtC.Text;

                if (string.IsNullOrEmpty(valorA) || string.IsNullOrEmpty(valorB) || string.IsNullOrEmpty(valorC))
                {
                    MessageBox.Show("Todos os valores precisam ser preenchidos");
                }
                else
                {
                    ladoA = double.Parse(txtA.Text);
                    ladoB = double.Parse(txtB.Text);           //VALIDAÇÃO DE FORMATO
                    ladoC = double.Parse(txtC.Text);

                    if (ladoA + ladoB < ladoC || ladoA + ladoC < ladoB || ladoB + ladoC < ladoA)
                    {
                        MessageBox.Show("Impossível de se formar um triângulo, siga as regras de formação de um triângulo:" +   //CONDIÇÃO DO TRIÂNGULO
                            "A+B>C, A+C>B, B+C>A");
                        resultado = ("");
                        lblResultado.Text = resultado;
                    }
                    else if (ladoA == 0 || ladoB == 0 || ladoC == 0)
                    {
                        MessageBox.Show("Os valores inseridos devem ser maiores que 0");              //TESTE DE VALOR MAIOR QUE 0
                        resultado = ("");
                        lblResultado.Text = resultado;
                    }

                    else if (ladoA == ladoB && ladoB == ladoC)
                    {
                        resultado = ("Triângulo Equilátero");        //CONDIÇÃO EQUILÁTERO
                        lblResultado.Text = resultado;
                    }

                    else if (ladoA == ladoB && ladoB != ladoC || ladoA == ladoB && ladoA != ladoC || ladoA == ladoC && ladoC != ladoB || ladoA == ladoC && ladoA != ladoB || ladoB == ladoC && ladoB != ladoA || ladoB == ladoC && ladoC != ladoA)
                    {
                        resultado = ("Triângulo  Isóceles");          //CONDIÇÃO ISÓCELES
                        lblResultado.Text = resultado;
                    }

                    else if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                    {
                        resultado = ("Triângulo  Escaleno");    //CONDIÇÃO ESCALENO
                        lblResultado.Text = resultado;
                    }
                }
            }

            catch (Exception)
            {
                MessageBox.Show("Insira apenas números");                   //VALIDAÇÃO DE FORMATO
            }
                
            if (ladoA <= 0)
                txtA.Focus();

            else if (ladoB <= 0)            //FOCO NO TXT ERRADO
                txtB.Focus();

            else txtC.Focus();
       
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();               //BOTÃO LIMPAR
            txtC.Clear();
            lblResultado.ResetText();
        }
    }
}
